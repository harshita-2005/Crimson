import argparse
import string
import re
from collections import Counter

# Common stop words list
STOP_WORDS = {"the", "is", "and", "a", "an", "to", "of", "in", "it", "that", "this", "with", "as", "for", "on", "at", "by", "from"}

def clean_text(text):
    """Remove punctuation and convert to lowercase."""
    text = text.lower()  # Convert to lowercase
    text = text.translate(str.maketrans("", "", string.punctuation))  # Remove punctuation
    return text

def count_words(text):
    """Count words excluding stop words."""
    words = text.split()
    filtered_words = [word for word in words if word not in STOP_WORDS]
    return len(words), filtered_words

def most_frequent_words(word_list, top_n=5):
    """Return the top N most frequent words."""
    word_counts = Counter(word_list)
    return word_counts.most_common(top_n)

def average_word_length(word_list):
    """Calculate the average length of words."""
    if not word_list:
        return 0
    total_length = sum(len(word) for word in word_list)
    return total_length / len(word_list)

def count_sentences(text):
    """Count the number of sentences using punctuation as delimiters."""
    sentences = re.split(r'[.!?]+', text)
    return len([s for s in sentences if s.strip()])

def analyze_file(file_path):
    """Read the file and analyze its text content."""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            text = file.read()
        
        cleaned_text = clean_text(text)
        
        total_words, filtered_words = count_words(cleaned_text)
        top_words = most_frequent_words(filtered_words)
        avg_word_len = average_word_length(filtered_words)
        sentence_count = count_sentences(text)

        # Display results
        print("\n--- File Analysis Report ---")
        print(f"Total words: {total_words}")
        print(f"Number of sentences: {sentence_count}")
        print(f"Average word length: {avg_word_len:.2f}")
        print("Top 5 most frequent words:")
        for word, count in top_words:
            print(f"  {word}: {count}")

    except FileNotFoundError:
        print("Error: The specified file does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

def main():
    parser = argparse.ArgumentParser(description="Analyze a text file and generate a summary report.")
    parser.add_argument("file", help="Path to the text file to analyze")

    args = parser.parse_args()
    analyze_file(args.file)

if __name__ == "__main__":
    main()
