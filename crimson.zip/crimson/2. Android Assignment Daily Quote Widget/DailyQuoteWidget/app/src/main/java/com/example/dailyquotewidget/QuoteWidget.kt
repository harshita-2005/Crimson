package com.example.dailyquotewidget
import android.content.ComponentName
import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
class QuoteWidget : AppWidgetProvider() {

    private val quotes = listOf(
        "Believe you can and you're halfway there.|Theodore Roosevelt",
        "The only way to do great work is to love what you do.|Steve Jobs",
        "You are stronger than you think.|Unknown",
        "Success is not final, failure is not fatal: It is the courage to continue that counts.|Winston Churchill",
        "Act as if what you do makes a difference. It does.|William James"
        // Add more quotes here
    )

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (widgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, widgetId)
        }
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        super.onReceive(context, intent)
        if (intent?.action == "UPDATE_QUOTE") {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context!!, QuoteWidget::class.java))
            onUpdate(context, manager, ids)
        }
    }

    private fun updateAppWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.quote_widget)

        val (quote, author) = quotes.random().split("|")
        views.setTextViewText(R.id.quote_text, "\"$quote\"")
        views.setTextViewText(R.id.quote_author, "- $author")

        val intent = Intent(context, QuoteWidget::class.java).apply {
            action = "UPDATE_QUOTE"
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_container, pendingIntent)

        manager.updateAppWidget(widgetId, views)
    }
}
