# Daily Quote Widget

A simple Android widget that displays a random motivational quote.

## Features
- Shows a new quote from a list.
- Designed using AppWidgetProvider.
- Quotes can be updated in `QuoteWidget.kt`.

## How to Use
1. Install and run the app.
2. Long press on home screen > Widgets > Add "Daily Quote Widget".
